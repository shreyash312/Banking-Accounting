package com.axis.utility;

public interface AppConstant {

	public static final String CUSTOMER_ID_NOT_FOUND_MESSAGE = "No customerId present for search";
	
	public static final String INSUFFIENT_BALANCE="Insuffient Balance";
}
