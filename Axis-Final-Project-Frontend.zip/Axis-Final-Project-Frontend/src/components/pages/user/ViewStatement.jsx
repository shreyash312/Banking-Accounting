import React from "react";


const ViewStatement = () => {
    return(
        <>
        <p class="text-center fs-1" id="adminHead">Transaction Statements </p>
        </>
    )
}
export default ViewStatement;