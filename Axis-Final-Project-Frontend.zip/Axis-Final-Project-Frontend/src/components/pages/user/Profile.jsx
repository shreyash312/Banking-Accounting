import React from "react";
const Profile = () => {
    return(
        <>
        <div className="row p-2">
        <p class="text-center fs-1" id="adminHead">User Profile</p>
        <div class="col-md-6 cardx">
          <a class="text-decoration-none bg-custom">
            <div class="card paint-card">
              <div class="card-body text-center">
              <i class="bi bi-bank"></i>
                <br />
                <p class="fs-3 text-dark"> Account No </p>
                <p class="fs-3 text-dark"></p>
              </div>
            </div>
          </a>
        </div>
        <div class="col-md-6">
          <a class="text-decoration-none bg-custom">
            <div class="card paint-card ">
              <div class="card-body text-center">
              <i class="bi bi-bank"></i>
                <br />
                <p class="fs-3 text-dark">Customer ID</p>
                <p class="fs-3 text-dark"></p>
              </div>
            </div>
          </a>
        </div>
      </div>
        </>
    )}
    export default Profile;