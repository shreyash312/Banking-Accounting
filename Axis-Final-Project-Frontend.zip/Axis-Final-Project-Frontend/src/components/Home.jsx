import React from 'react'

function home() {
  return (
    <div>home page</div>
  )
}

export default home